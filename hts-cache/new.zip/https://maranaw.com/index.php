<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
	<!-- Open Graph (Facebook, Messenger, LinkedIn) -->
	<meta property="og:title" content="Maranao Tafsir – Tafsir sa Basa Maranao">
	<meta property="og:description" content="Official Maranao Tafsir resource online – rooted in the work of Engr. Abdulbasit Tamano.">
	<meta property="og:image" content="https://tafsir.maranaw.com/images/og-image.jpg">
	<meta property="og:url" content="https://tafsir.maranaw.com/">
	<meta property="og:type" content="website">

	<!-- Twitter / X Card -->
	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:title" content="Maranao Tafsir – Tafsir sa Basa Maranao">
	<meta name="twitter:description" content="Official Maranao Tafsir resource online – rooted in the work of Engr. Abdulbasit Tamano.">
	<meta name="twitter:image" content="https://tafsir.maranaw.com/images/og-image.jpg">
	<meta name="twitter:site" content="@YourHandle"> <!-- optional -->
    <title>Maranaw Tafsir</title>
    <link rel="stylesheet" href="style_landing.css">
    <link rel="icon" type="image/png" href="images/favicon.png">

</head>
<style>
.site-footer {
        max-width: 1000px;    /* match content width */
        margin: 20px auto;    /* center horizontally */
        padding: 20px 0;
        text-align: center;
        color: #666;
        font-size: 14px;
    }
</style>
<link rel="stylesheet" href="responsive.css">

<body>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Maranao Tafsir</title>
<style>
body {
    margin: 0;
    padding: 0;
    font-family: 'Merriweather', serif;
}

/* Header styles */
header {
    width: 100%;
    background-color: #000;
    color: #fff;
}

.header-inner {
    max-width: 1000px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
    flex-wrap: wrap; /* allows wrapping on smaller screens */
}

/* Logo styles */
.logo a {
    color: inherit;
    text-decoration: none;
    display: flex;
    align-items: center;
}

.logo img {
    width: 64px;  /* default desktop size */
    height: 64px;
    margin-right: 10px;
}

/* Navigation styles */
.main-nav {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
}

.main-nav a {
    color: #fff;
    text-decoration: none;
    /*font-weight: bold;*/
    font-family: 'Merriweather', serif;
    font-size: 16px;
}

.main-nav a:hover {
    color: #ccc;
}

/* Horizontal rule */
hr {
    width: 100%;
    border: 1px solid #ccc;
    margin: 0;
}

/* Mobile adjustments */
@media (max-width: 600px) {
    .header-inner {
        flex-direction: column;
        align-items: flex-start;
    }

    .logo img {
        width: 64px;   /* smaller logo on mobile */
        height: 64px;
        margin-right: 8px;
    }

    .main-nav {
        gap: 10px;
        flex-direction: column;
        width: 100%;
    }
}
</style>
</head>
<body>
<header>
<!-- Open Graph (Facebook, Messenger, LinkedIn) -->
<meta property="og:title" content="Maranao Tafsir – Tafsir sa Basa Maranao">
<meta property="og:description" content="Official Maranao Tafsir resource online – rooted in the work of Engr. Abdulbasit Tamano.">
<meta property="og:image" content="https://tafsir.maranaw.com/images/og-image.jpg">
<meta property="og:url" content="https://tafsir.maranaw.com/">
<meta property="og:type" content="website">

<!-- Twitter / X Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Maranao Tafsir – Tafsir sa Basa Maranao">
<meta name="twitter:description" content="Official Maranao Tafsir resource online – rooted in the work of Engr. Abdulbasit Tamano.">
<meta name="twitter:image" content="https://tafsir.maranaw.com/images/og-image.jpg">
<meta name="twitter:site" content="@YourHandle"> <!-- optional -->

<div class="header-inner">
    <div class="logo">
        <a href="index.php">
            <img src="images/logo-64x64.png" alt="Maranao Tafsir Logo">
            Maranao Tafsir
        </a>
    </div>
    <nav class="main-nav">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="home.php">Surah Index</a>
        <a href="contact.php">Contact</a>
        <a href="search.php">Search</a>
        <a href="https://drive.google.com/file/d/1lV7Fz8tb_4Bj7Zao1-uzdRH_OsSxm0KV/view">Get PDF</a>
        <a href="https://maranaw.com/myquran" target="_blank">Get Mobile App</a>
    </nav>
</div>

</header>
<hr>
<hr>

<main class="site-content">
    <h1>Welcome to Maranaw Tafsir</h1>
    <p>
        The Maranaw Tafsir website makes the Qur’an more accessible to the Maranaw community with translation and tafsir by Abu Ahmad Tamano. Now you can read, listen, and reflect — play every ayah with your favorite reciter, add verses to Favorites, copy them for study, or share them directly on social media.
    </p>
    <a href="home.php" class="browse-surahs">Browse Surahs</a>
	<p>To read offline, click the download button below</p>
	<a href="https://drive.google.com/file/d/1lV7Fz8tb_4Bj7Zao1-uzdRH_OsSxm0KV/view" class="browse-surahs">Download PDF</a>

</main>
    <footer>
        <div class="site-footer">
            <p>&copy; 2025 Maranaw Tafsir by <strong>Abu Ahmad Tamano.</strong> | Site developed by <strong>Ashary Tamano</strong>. | All rights reserved.</p>
        </div>
    </footer>

</body>
</html>

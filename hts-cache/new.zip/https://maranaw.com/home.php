<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
	<!-- Open Graph (Facebook, Messenger, LinkedIn) -->
	<meta property="og:title" content="Maranao Tafsir – Tafsir sa Basa Maranao">
	<meta property="og:description" content="Official Maranao Tafsir resource online – rooted in the work of Engr. Abdulbasit Tamano.">
	<meta property="og:image" content="https://tafsir.maranaw.com/images/og-image.jpg">
	<meta property="og:url" content="https://tafsir.maranaw.com/">
	<meta property="og:type" content="website">

	<!-- Twitter / X Card -->
	<meta name="twitter:card" content="summary_large_image">
	<meta name="twitter:title" content="Maranao Tafsir – Tafsir sa Basa Maranao">
	<meta name="twitter:description" content="Official Maranao Tafsir resource online – rooted in the work of Engr. Abdulbasit Tamano.">
	<meta name="twitter:image" content="https://tafsir.maranaw.com/images/og-image.jpg">
	<meta name="twitter:site" content="@YourHandle"> <!-- optional -->
    <title>Surah Index - Maranaw Tafsir</title>
    <link rel="stylesheet" href="style_landing.css">
    <style>
        /* Surah index styling */
        .surah-index {
            max-width: 1000px;
            margin: 40px auto;
            padding: 0 20px;
        }

        .surah-index h1 {
            text-align: center;
            font-size: 32px;
            margin-bottom: 30px;
        }

        .surah-table {
            width: 100%;
            border-collapse: collapse;
            text-align: center;
        }

        .surah-table td {
            vertical-align: top;
            padding: 15px;
            border: 1px solid #ccc;
            transition: background-color 0.3s, transform 0.2s;
        }

        /* Zebra stripe effect - more noticeable */
        .surah-table tr:nth-child(odd) td {
            background-color: #dcdcdc; /* darker gray */
        }

        .surah-table tr:nth-child(even) td {
            background-color: #f0f0f0; /* lighter gray */
        }

        /* Hover effect on cells */
        .surah-table td:hover {
            background-color: #e0e0e0;
            transform: scale(1.03);
        }

        /* Surah link styling */
        .surah-link {
            text-decoration: none;
            color: #000;
            font-size: 18px;
        }

        .surah-link:hover {
            color: #333;
        }

        /* Arabic font */
        .arabic {
            font-family: 'Amiri', serif;
            font-size: 22px;
            margin-left: 5px;
        }
    </style>
<link rel="icon" type="image/png" href="images/favicon.png">

</head>
<body>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Maranao Tafsir</title>
<style>
body {
    margin: 0;
    padding: 0;
    font-family: 'Merriweather', serif;
}

/* Header styles */
header {
    width: 100%;
    background-color: #000;
    color: #fff;
}

.header-inner {
    max-width: 1000px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
    flex-wrap: wrap; /* allows wrapping on smaller screens */
}

/* Logo styles */
.logo a {
    color: inherit;
    text-decoration: none;
    display: flex;
    align-items: center;
}

.logo img {
    width: 64px;  /* default desktop size */
    height: 64px;
    margin-right: 10px;
}

/* Navigation styles */
.main-nav {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
}

.main-nav a {
    color: #fff;
    text-decoration: none;
    /*font-weight: bold;*/
    font-family: 'Merriweather', serif;
    font-size: 16px;
}

.main-nav a:hover {
    color: #ccc;
}

/* Horizontal rule */
hr {
    width: 100%;
    border: 1px solid #ccc;
    margin: 0;
}

/* Mobile adjustments */
@media (max-width: 600px) {
    .header-inner {
        flex-direction: column;
        align-items: flex-start;
    }

    .logo img {
        width: 64px;   /* smaller logo on mobile */
        height: 64px;
        margin-right: 8px;
    }

    .main-nav {
        gap: 10px;
        flex-direction: column;
        width: 100%;
    }
}
</style>
</head>
<body>
<header>
<!-- Open Graph (Facebook, Messenger, LinkedIn) -->
<meta property="og:title" content="Maranao Tafsir – Tafsir sa Basa Maranao">
<meta property="og:description" content="Official Maranao Tafsir resource online – rooted in the work of Engr. Abdulbasit Tamano.">
<meta property="og:image" content="https://tafsir.maranaw.com/images/og-image.jpg">
<meta property="og:url" content="https://tafsir.maranaw.com/">
<meta property="og:type" content="website">

<!-- Twitter / X Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Maranao Tafsir – Tafsir sa Basa Maranao">
<meta name="twitter:description" content="Official Maranao Tafsir resource online – rooted in the work of Engr. Abdulbasit Tamano.">
<meta name="twitter:image" content="https://tafsir.maranaw.com/images/og-image.jpg">
<meta name="twitter:site" content="@YourHandle"> <!-- optional -->

<div class="header-inner">
    <div class="logo">
        <a href="index.php">
            <img src="images/logo-64x64.png" alt="Maranao Tafsir Logo">
            Maranao Tafsir
        </a>
    </div>
    <nav class="main-nav">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="home.php">Surah Index</a>
        <a href="contact.php">Contact</a>
        <a href="search.php">Search</a>
        <a href="https://drive.google.com/file/d/1lV7Fz8tb_4Bj7Zao1-uzdRH_OsSxm0KV/view">Get PDF</a>
        <a href="https://maranaw.com/myquran" target="_blank">Get Mobile App</a>
    </nav>
</div>

</header>
<hr>
<hr>

<main class="site-content">
    <div class="surah-index">
        <h1>Surah Index</h1>
        <table class="surah-table">
            <tbody>
                <tr><td><a class='surah-link' href='surah.php?surah=1'><strong>1. Al-Fatihah | <span class='arabic'>ٱلْفَاتِحَة</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=2'><strong>2. Al-Baqarah | <span class='arabic'>ٱلْبَقَرَة</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=3'><strong>3. Al-Imran | <span class='arabic'>آل عِمْرَان</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=4'><strong>4. An-Nisa | <span class='arabic'>ٱلنِّسَاء</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=5'><strong>5. Al-Ma&#039;idah | <span class='arabic'>ٱلْمَائِدَة</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=6'><strong>6. Al-An&#039;am | <span class='arabic'>ٱلْأَنْعَام</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=7'><strong>7. Al-A&#039;raf | <span class='arabic'>ٱلْأَعْرَاف</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=8'><strong>8. Al-Anfal | <span class='arabic'>ٱلْأَنْفَال</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=9'><strong>9. At-Tawbah | <span class='arabic'>ٱلتَّوْبَة</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=10'><strong>10. Yunus | <span class='arabic'>يُونُس</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=11'><strong>11. Hud | <span class='arabic'>هُود</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=12'><strong>12. Yusuf | <span class='arabic'>يُوسُف</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=13'><strong>13. Ar-Ra&#039;d | <span class='arabic'>الرَّعْد</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=14'><strong>14. Ibrahim | <span class='arabic'>إبْرَاهِيم</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=15'><strong>15. Al-Hijr | <span class='arabic'>الْحِجْر</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=16'><strong>16. An-Nahl | <span class='arabic'>النَّحْل</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=17'><strong>17. Al-Isra | <span class='arabic'>الإسْرَاء</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=18'><strong>18. Al-Kahf | <span class='arabic'>الْكَهْف</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=19'><strong>19. Maryam | <span class='arabic'>مَرْيَم</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=20'><strong>20. Ta-Ha | <span class='arabic'>طه</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=21'><strong>21. Al-Anbiya | <span class='arabic'>الأنْبِيَاء</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=22'><strong>22. Al-Hajj | <span class='arabic'>الْحَجّ</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=23'><strong>23. Al-Mu&#039;minun | <span class='arabic'>المُؤْمِنُون</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=24'><strong>24. An-Nur | <span class='arabic'>النُّور</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=25'><strong>25. Al-Furqan | <span class='arabic'>الْفُرْقَان</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=26'><strong>26. Ash-Shu&#039;ara | <span class='arabic'>الشُّعَرَاء</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=27'><strong>27. An-Naml | <span class='arabic'>النَّمْل</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=28'><strong>28. Al-Qasas | <span class='arabic'>الْقَصَص</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=29'><strong>29. Al-Ankabut | <span class='arabic'>العَنْكَبُوت</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=30'><strong>30. Ar-Rum | <span class='arabic'>الرُّوم</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=31'><strong>31. Luqman | <span class='arabic'>لُقْمَان</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=32'><strong>32. As-Sajdah | <span class='arabic'>السَّجْدَة</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=33'><strong>33. Al-Ahzab | <span class='arabic'>الأحْزَاب</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=34'><strong>34. Saba | <span class='arabic'>سَبَأ</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=35'><strong>35. Fatir | <span class='arabic'>فَاطِر</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=36'><strong>36. Ya-Sin | <span class='arabic'>يَس</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=37'><strong>37. As-Saffat | <span class='arabic'>الصَّافَّات</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=38'><strong>38. Sad | <span class='arabic'>ص</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=39'><strong>39. Az-Zumar | <span class='arabic'>الزُّمَر</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=40'><strong>40. Ghafir | <span class='arabic'>غَافِر</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=41'><strong>41. Fussilat | <span class='arabic'>فُصِّلَت</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=42'><strong>42. Ash-Shura | <span class='arabic'>الشُّورَى</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=43'><strong>43. Az-Zukhruf | <span class='arabic'>الزُّخْرُف</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=44'><strong>44. Ad-Dukhan | <span class='arabic'>الدُّخَان</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=45'><strong>45. Al-Jathiyah | <span class='arabic'>الجَاثِيَة</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=46'><strong>46. Al-Ahqaf | <span class='arabic'>الأحْقَاف</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=47'><strong>47. Muhammad | <span class='arabic'>مُحَمَّد</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=48'><strong>48. Al-Fath | <span class='arabic'>الْفَتْح</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=49'><strong>49. Al-Hujurat | <span class='arabic'>الحُجُرَات</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=50'><strong>50. Qaf | <span class='arabic'>ق</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=51'><strong>51. Adh-Dhariyat | <span class='arabic'>الذَّارِيَات</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=52'><strong>52. At-Tur | <span class='arabic'>الطُّور</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=53'><strong>53. An-Najm | <span class='arabic'>النَّجْم</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=54'><strong>54. Al-Qamar | <span class='arabic'>الْقَمَر</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=55'><strong>55. Ar-Rahman | <span class='arabic'>الرَّحْمَان</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=56'><strong>56. Al-Waqi&#039;ah | <span class='arabic'>الْوَاقِعَة</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=57'><strong>57. Al-Hadid | <span class='arabic'>الْحَدِيد</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=58'><strong>58. Al-Mujadila | <span class='arabic'>المُجَادِلَة</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=59'><strong>59. Al-Hashr | <span class='arabic'>الحَشْر</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=60'><strong>60. Al-Mumtahanah | <span class='arabic'>المُمْتَحَنَة</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=61'><strong>61. As-Saff | <span class='arabic'>الصَّف</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=62'><strong>62. Al-Jumu&#039;ah | <span class='arabic'>الْجُمُعَة</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=63'><strong>63. Al-Munafiqun | <span class='arabic'>المُنَافِقُون</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=64'><strong>64. At-Taghabun | <span class='arabic'>التَّغَابُن</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=65'><strong>65. At-Talaq | <span class='arabic'>الطَّلَاق</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=66'><strong>66. At-Tahrim | <span class='arabic'>التَّحْرِيم</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=67'><strong>67. Al-Mulk | <span class='arabic'>الْمُلْك</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=68'><strong>68. Al-Qalam | <span class='arabic'>القَلَم</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=69'><strong>69. Al-Haqqah | <span class='arabic'>الحَاقَّة</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=70'><strong>70. Al-Ma&#039;arij | <span class='arabic'>المَعَارِج</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=71'><strong>71. Nuh | <span class='arabic'>نُوح</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=72'><strong>72. Al-Jinn | <span class='arabic'>الجِنّ</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=73'><strong>73. Al-Muzzammil | <span class='arabic'>المُزَّمِّل</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=74'><strong>74. Al-Muddaththir | <span class='arabic'>المُدَّثِّر</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=75'><strong>75. Al-Qiyamah | <span class='arabic'>الْقِيَامَة</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=76'><strong>76. Al-Insan | <span class='arabic'>الإِنْسَان</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=77'><strong>77. Al-Mursalat | <span class='arabic'>الْمُرْسَلَات</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=78'><strong>78. An-Naba | <span class='arabic'>النَّبَأ</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=79'><strong>79. An-Nazi&#039;at | <span class='arabic'>النَّازِعَات</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=80'><strong>80. Abasa | <span class='arabic'>عَبَس</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=81'><strong>81. At-Takwir | <span class='arabic'>التَّكْوِير</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=82'><strong>82. Al-Infitar | <span class='arabic'>الانفِطَار</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=83'><strong>83. Al-Mutaffifin | <span class='arabic'>المُطَفِّفِين</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=84'><strong>84. Al-Inshiqaq | <span class='arabic'>الانشِقَاق</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=85'><strong>85. Al-Buruj | <span class='arabic'>البُرُوج</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=86'><strong>86. At-Tariq | <span class='arabic'>الطَّارِق</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=87'><strong>87. Al-A&#039;la | <span class='arabic'>الأعلى</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=88'><strong>88. Al-Ghashiyah | <span class='arabic'>الغَاشِيَة</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=89'><strong>89. Al-Fajr | <span class='arabic'>الفَجْر</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=90'><strong>90. Al-Balad | <span class='arabic'>البَلَد</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=91'><strong>91. Ash-Shams | <span class='arabic'>الشَّمْس</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=92'><strong>92. Al-Lail | <span class='arabic'>اللَّيْل</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=93'><strong>93. Ad-Duhaa | <span class='arabic'>الضُّحَى</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=94'><strong>94. Ash-Sharh | <span class='arabic'>الشَّرْح</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=95'><strong>95. At-Tin | <span class='arabic'>التِّين</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=96'><strong>96. Al-Alaq | <span class='arabic'>الْعَلَق</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=97'><strong>97. Al-Qadr | <span class='arabic'>الْقَدْر</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=98'><strong>98. Al-Bayyinah | <span class='arabic'>البَيِّنَة</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=99'><strong>99. Az-Zalzalah | <span class='arabic'>الزَّلْزَلَة</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=100'><strong>100. Al-Adiyat | <span class='arabic'>الْعَادِيَات</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=101'><strong>101. Al-Qari&#039;ah | <span class='arabic'>القَارِعَة</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=102'><strong>102. At-Takathur | <span class='arabic'>التَّكَاثُر</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=103'><strong>103. Al-Asr | <span class='arabic'>العَصْر</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=104'><strong>104. Al-Humazah | <span class='arabic'>الْهُمَزَة</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=105'><strong>105. Al-Fil | <span class='arabic'>الفِيل</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=106'><strong>106. Quraish | <span class='arabic'>قُرَيْش</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=107'><strong>107. Al-Ma&#039;un | <span class='arabic'>المَاعُون</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=108'><strong>108. Al-Kawthar | <span class='arabic'>الْكَوْثَر</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=109'><strong>109. Al-Kafirun | <span class='arabic'>الكَافِرُون</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=110'><strong>110. An-Nasr | <span class='arabic'>النَّصْر</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=111'><strong>111. Al-Masad | <span class='arabic'>المَسَد</span></strong></a></td></tr><tr><td><a class='surah-link' href='surah.php?surah=112'><strong>112. Al-Ikhlas | <span class='arabic'>الإخْلَاص</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=113'><strong>113. Al-Falaq | <span class='arabic'>الفَلَق</span></strong></a></td><td><a class='surah-link' href='surah.php?surah=114'><strong>114. An-Nas | <span class='arabic'>النَّاس</span></strong></a></td></tr><tr></tr>            </tbody>
        </table>
    </div>
</main>
<hr>
    <footer>
        <div class="site-footer">
            <p>&copy; 2025 Maranaw Tafsir by <strong>Abu Ahmad Tamano.</strong> | Site developed by <strong>Ashary Tamano</strong>. | All rights reserved.</p>
        </div>
    </footer>

</body>
</html>

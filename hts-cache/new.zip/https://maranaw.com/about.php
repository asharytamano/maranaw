<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Maranao Tafsir</title>
<style>
body {
    margin: 0;
    padding: 0;
    font-family: 'Merriweather', serif;
}

/* Header styles */
header {
    width: 100%;
    background-color: #000;
    color: #fff;
}

.header-inner {
    max-width: 1000px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
    flex-wrap: wrap; /* allows wrapping on smaller screens */
}

/* Logo styles */
.logo a {
    color: inherit;
    text-decoration: none;
    display: flex;
    align-items: center;
}

.logo img {
    width: 64px;  /* default desktop size */
    height: 64px;
    margin-right: 10px;
}

/* Navigation styles */
.main-nav {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
}

.main-nav a {
    color: #fff;
    text-decoration: none;
    /*font-weight: bold;*/
    font-family: 'Merriweather', serif;
    font-size: 16px;
}

.main-nav a:hover {
    color: #ccc;
}

/* Horizontal rule */
hr {
    width: 100%;
    border: 1px solid #ccc;
    margin: 0;
}

/* Mobile adjustments */
@media (max-width: 600px) {
    .header-inner {
        flex-direction: column;
        align-items: flex-start;
    }

    .logo img {
        width: 64px;   /* smaller logo on mobile */
        height: 64px;
        margin-right: 8px;
    }

    .main-nav {
        gap: 10px;
        flex-direction: column;
        width: 100%;
    }
}
</style>
</head>
<body>
<header>
<!-- Open Graph (Facebook, Messenger, LinkedIn) -->
<meta property="og:title" content="Maranao Tafsir – Tafsir sa Basa Maranao">
<meta property="og:description" content="Official Maranao Tafsir resource online – rooted in the work of Engr. Abdulbasit Tamano.">
<meta property="og:image" content="https://tafsir.maranaw.com/images/og-image.jpg">
<meta property="og:url" content="https://tafsir.maranaw.com/">
<meta property="og:type" content="website">

<!-- Twitter / X Card -->
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Maranao Tafsir – Tafsir sa Basa Maranao">
<meta name="twitter:description" content="Official Maranao Tafsir resource online – rooted in the work of Engr. Abdulbasit Tamano.">
<meta name="twitter:image" content="https://tafsir.maranaw.com/images/og-image.jpg">
<meta name="twitter:site" content="@YourHandle"> <!-- optional -->

<div class="header-inner">
    <div class="logo">
        <a href="index.php">
            <img src="images/logo-64x64.png" alt="Maranao Tafsir Logo">
            Maranao Tafsir
        </a>
    </div>
    <nav class="main-nav">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="home.php">Surah Index</a>
        <a href="contact.php">Contact</a>
        <a href="search.php">Search</a>
        <a href="https://drive.google.com/file/d/1lV7Fz8tb_4Bj7Zao1-uzdRH_OsSxm0KV/view">Get PDF</a>
        <a href="https://maranaw.com/myquran" target="_blank">Get Mobile App</a>
    </nav>
</div>

</header>
<hr>
<hr>

<!-- Embedded styles for About Page -->
<style>
    .site-content {
        max-width: 1000px;   /* controls content width */
        margin: 20px auto;   /* centers horizontally */
        padding: 0 20px;     /* side padding */
    }
    .site-content h1 {
        font-size: 32px;
        text-align: center;
        margin: 40px 0 30px 0;
        font-weight: bold;
    }
    .site-content p {
        font-size: 18px;
        line-height: 1.8;
        margin-bottom: 20px;
        color: #333;
    }
    .site-content strong {
        font-weight: bold;
        color: #000;
    }
    .site-footer {
        max-width: 1000px;    /* match content width */
        margin: 20px auto;    /* center horizontally */
        padding: 20px 0;
        text-align: center;
        color: #666;
        font-size: 14px;
    }
</style>

<main class="site-content">
    <h1>About the Project</h1>

    <p>
        This website is dedicated to <em>Tafsir sa Basa Maranao</em>—the first complete 
        interpretation of the Holy Qur’an in the Maranao language. It was authored by Abu Ahmad Tamano, a lifelong advocate for making the Qur’an accessible to 
        Maranaos in their mother tongue.
    </p>

    <p>
        The project began with a vision: to strengthen faith and understanding by presenting 
        the timeless words of the Qur’an in the language of the Maranao people. This effort 
        preserves and honors our culture while making the Qur’an’s message more immediate 
        and meaningful for every reader.
    </p>

    <p>
        Through this site, readers can explore the Tafsir, access supporting materials, 
        and reflect on insights meant to inspire daily life. It is part of an ongoing mission 
        to bridge tradition, language, and modern technology for the benefit of present and 
        future generations.
    </p>

    <p>
        <strong>Our Mission:</strong> To provide Maranaos with a reliable, readable, and 
        culturally rooted Tafsir in their own language, while also supporting scholars, 
        students, and families seeking deeper understanding.
    </p>

    <p>
        <strong>Our Vision:</strong> A community of believers enriched by knowledge, proud 
        of their heritage, and empowered to live by the teachings of the Qur’an.
    </p>
</main>
<hr>
    <footer>
        <div class="site-footer">
            <p>&copy; 2025 Maranaw Tafsir by <strong>Abu Ahmad Tamano.</strong> | Site developed by <strong>Ashary Tamano</strong>. | All rights reserved.</p>
        </div>
    </footer>
